package com.example.logandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ThirdActivity extends AppCompatActivity {
    TextView result;
    EditText editData1,editData2,editData3,editData4,editData5,editData6,editData7,editData8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        result=(TextView)findViewById(R.id.result);
        loadBattteryInfo();
        editData1=(EditText)findViewById(R.id.editData1);
        editData2=(EditText)findViewById(R.id.editData2);
        editData3=(EditText)findViewById(R.id.editData3);
        editData4=(EditText)findViewById(R.id.editData4);
        editData5=(EditText)findViewById(R.id.editData5);
        editData6=(EditText)findViewById(R.id.editData6);
        editData7=(EditText)findViewById(R.id.editData7);
        editData8=(EditText)findViewById(R.id.editData8);
        this.setTitle("Battery");
    }
    private void loadBattteryInfo(){
        IntentFilter intentFilter=new IntentFilter();
        intentFilter.addAction(Intent.ACTION_POWER_CONNECTED);
        intentFilter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        intentFilter.addAction(Intent.ACTION_BATTERY_CHANGED);

        registerReceiver(batteryInfoReceiver, intentFilter);
    }
    private BroadcastReceiver batteryInfoReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateBatteryData(intent);
        }
    };


    private void updateBatteryData(Intent intent) {
        boolean present = intent.getBooleanExtra(BatteryManager.EXTRA_PRESENT, false);

        if (present) {
            StringBuilder batteryInfo=new StringBuilder();
            int health = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, 0);
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);

            if (level != -1 && scale != -1) {
                int batteryPct = (int) ((level / (float) scale) * 100f);
                if(batteryPct>50){
                    editData1.setText("Battery: "+batteryPct+"%");
                    editData1.getBackground().setColorFilter(Color.GREEN, PorterDuff.Mode.MULTIPLY);
                }
                if(batteryPct<50 && batteryPct>30){
                    editData1.setText("Battery: "+batteryPct+"%");
                    editData1.getBackground().setColorFilter(Color.BLUE, PorterDuff.Mode.MULTIPLY);
                }
                if(batteryPct<30){
                    editData1.setText("Battery: "+batteryPct+"%");
                    editData1.getBackground().setColorFilter(Color.RED, PorterDuff.Mode.MULTIPLY);
                }
            }

            int plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0);
            switch (health) {
                case BatteryManager.BATTERY_HEALTH_COLD:
                    editData2.setText("Health: Cold");
                    break;
                case BatteryManager.BATTERY_HEALTH_DEAD:
                    editData2.setText("Health: Dead");
                    break;
                case BatteryManager.BATTERY_HEALTH_GOOD:
                    editData2.setText("Health: Good");
                    break;
                case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                    editData2.setText("Health: Over Voltage");
                    break;
                case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                    editData2.setText("Health: Overheat");
                    break;
                case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                    editData2.setText("Unspecified Failure");
                    break;
                case BatteryManager.BATTERY_HEALTH_UNKNOWN:
                default:
                    editData2.setText("Health: "+health+"%");
                    break;
            }
            switch (plugged) {
                case BatteryManager.BATTERY_PLUGGED_WIRELESS:
                    editData3.setText("Plugged: Wireless");
                    break;
                case BatteryManager.BATTERY_PLUGGED_USB:
                    editData3.setText("Plugged: usb");
                    break;

                case BatteryManager.BATTERY_PLUGGED_AC:
                    editData3.setText("Plugged: ac");
                    break;
                default:
                    editData3.setText("Plugged: "+plugged);
                    break;
            }
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);

            switch (status) {
                case BatteryManager.BATTERY_STATUS_CHARGING:
                    editData4.setText("Status: Charging");
                    break;
                case BatteryManager.BATTERY_STATUS_DISCHARGING:
                    editData4.setText("Status: Discharge");
                    break;
                case BatteryManager.BATTERY_STATUS_FULL:
                    editData4.setText("Status: Full");
                    break;
                case BatteryManager.BATTERY_STATUS_UNKNOWN:
                    editData4.setText("Status: Unknown");
                    break;
                case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                    editData4.setText("Status: Not Charging");
                    break;
                default:
                    editData4.setText("Status: Discharging");
                    break;
            }
            if (intent.getExtras() != null) {
                String technology = intent.getExtras().getString(BatteryManager.EXTRA_TECHNOLOGY);

                if (!"".equals(technology)) {
                    editData5.setText("Technology: "+technology);

                }
            }

            int temperature = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0);

            if (temperature > 0) {
                float temp = ((float) temperature) / 10f;

                editData6.setText("Temperature: "+temp+ " °C");
            }

            int voltage = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0);

            if (voltage > 0) {
                editData7.setText("Voltage: "+voltage+ " mV");
            }

            long capacity = getBatteryCapacity(this);

            if (capacity > 0) {
                editData8.setText("Capacity: "+capacity+ " mAh");
            }

        } else {
            Toast.makeText(this, "No Battery present", Toast.LENGTH_SHORT).show();
        }

    }


    public long getBatteryCapacity(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            BatteryManager mBatteryManager = (BatteryManager) ctx.getSystemService(Context.BATTERY_SERVICE);
            Long chargeCounter = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            Long capacity = mBatteryManager.getLongProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

            if (chargeCounter != null && capacity != null) {
                long value = (long) (((float) chargeCounter / (float) capacity) * 100f);
                return value;
            }
        }

        return 0;
    }




}
