package com.example.logandroid;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;


import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.nfc.Tag;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

import java.io.File;
import java.io.FileReader;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class MainActivity extends AppCompatActivity {
    private static final int WRITE_EXTERNAL_STORAGE_CODE = 1;
    private static final String TAG = "MyActivity";
    String mText = "";
    String myData = "";


    EditText editData1, editData2, editData3, editData4, editData5, editData6, editData7;

    View v;
       private static final int INDEX_NOT_FOUND = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setTitle("Logcat Information");
        editData1 = (EditText) findViewById(R.id.editData1);
        editData2 = (EditText) findViewById(R.id.editData2);
        editData3 = (EditText) findViewById(R.id.editData3);
        editData4 = (EditText) findViewById(R.id.editData4);
        editData5 = (EditText) findViewById(R.id.editData5);
        editData6 = (EditText) findViewById(R.id.editData6);
        editData7 = (EditText) findViewById(R.id.editData7);

        try {
            Process process = Runtime.getRuntime().exec("logcat -d");

            BufferedReader bufferedReader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));


            StringBuilder log = new StringBuilder();
            String line = "";
            while ((line = bufferedReader.readLine()) != null) {
                log.append(line);
                log.append("\n");
            }

            mText = log.toString().trim();
            if (mText.isEmpty()) {
                Toast.makeText(MainActivity.this, "please enter", Toast.LENGTH_SHORT).show();


            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
                        String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
                        requestPermissions(permissions, WRITE_EXTERNAL_STORAGE_CODE);
                    } else {
                        saveToTxtFile(mText);
                    }
                } else {
                    saveToTxtFile(mText);
                }
            }

        } catch (IOException e) {
        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case WRITE_EXTERNAL_STORAGE_CODE: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    saveToTxtFile(mText);
                } else {
                    Toast.makeText(MainActivity.this, "storage permission", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void saveToTxtFile(String mText) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(System.currentTimeMillis());

        try {
            File path = Environment.getExternalStorageDirectory();

            File dir = new File(path + "/My Files/");
            dir.mkdirs();
            String filename = "MyFile_to storage_" + timestamp + ".txt";
            File file = new File(dir, filename);
            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(mText);
            String info = " I ";
            String error = " E ";
            String debug = " D ";
            String warning = " W ";
            String asserts = " A ";
            String fatalException1 = "Fatal Exception";


            bw.close();
            int infocount = countWord(info, filename);

            editData4.append("Total Count="+String.valueOf(infocount));


            int errorcount = countWord(error, filename);
            editData1.append("Total Count="+String.valueOf(errorcount));
            //int debugcount=countWord(debug,filename);
            //editData2.setText(String.valueOf(debugcount));
            int warningcount = countWord(warning, filename);
            editData3.append("Total Count="+String.valueOf(warningcount));
            //int assertscount=countWord(asserts,filename);
            // editData5.setText(String.valueOf(assertscount));
            int fatalException = countWord(fatalException1, filename);
            editData6.append("Total Count="+String.valueOf(fatalException));
            clearLog();


        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }


    public void clearLog() {
        try {

            Process process = new ProcessBuilder()
                    .command("logcat", "-c")
                    .redirectErrorStream(true)
                    .start();
        } catch (IOException e) {
        }
    }

    public int countWord(String word, String file) {
        int count = 0;
        Map<String, Integer> dictionary = new HashMap<String, Integer>();
        Map dictionary1 = new HashMap();
        Map dictionary2 = new HashMap();
        Map dictionary3 = new HashMap();
        Map dictionary4 = new HashMap();
        try {
            FileInputStream fis = new FileInputStream("/storage/emulated/0/My Files/" + file);
            DataInputStream in = new DataInputStream(fis);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;


            while ((strLine = br.readLine()) != null) {

                String str = strLine;


                int ret = 0;

                if (word == " I ") {
                    ret = indexOfIgnoreCase(strLine, word, 0);

                    if (ret != -1) {
                        count++;


                        String retTag = wordsix(strLine);
                        if (retTag != " ") {

                            if (dictionary.containsKey(retTag)) {
                                Integer val = (Integer) dictionary.get(retTag);
                                dictionary.put(retTag, val + 1);
                            } else
                                dictionary.put(retTag, 1);
                        }
                    }

                }


                if (word == " W ") {
                    ret = indexOfIgnoreCase(strLine, word, 0);

                    if (ret != -1) {
                        count++;

                        String retTag = wordsix(strLine);

                        if (dictionary2.containsKey(retTag)) {
                            Integer val = (Integer) dictionary2.get(retTag);
                            dictionary2.put(retTag, val + 1);
                        } else
                            dictionary2.put(retTag, 1);
                    }

                }


                if (word == " E ") {
                    ret = indexOfIgnoreCase(strLine, word, 0);

                    if (ret != -1) {
                        count++;


                        String retTag = wordsix(strLine);

                        if (dictionary4.containsKey(retTag)) {
                            Integer val = (Integer) dictionary4.get(retTag);
                            dictionary4.put(retTag, val + 1);
                        } else
                            dictionary4.put(retTag, 1);
                    }

                }
                if (word == "Fatal Exception") {
                    ret = indexOfIgnoreCase(strLine, word, 0);

                    if (ret != -1) {
                        count++;


                        String retTag = wordsix(strLine);

                        if (dictionary3.containsKey(retTag)) {
                            Integer val = (Integer) dictionary3.get(retTag);
                            dictionary3.put(retTag, val + 1);
                        } else
                            dictionary3.put(retTag, 1);
                    }

                }


            }


            if (word == " I ") {

                Iterator entries = dictionary.entrySet().iterator();
                while (entries.hasNext()) {
                    Map.Entry entry = (Map.Entry) entries.next();
                    String key = (String) entry.getKey();
                    Integer value = (Integer) entry.getValue();
                    editData4.append(key + "=" + value + "\n");
                }

            }


            if (word == " E ") {

                Iterator entries = dictionary4.entrySet().iterator();
                while (entries.hasNext()) {
                    Map.Entry entry = (Map.Entry) entries.next();
                    String key = (String) entry.getKey();
                    Integer value = (Integer) entry.getValue();
                    editData1.append(key + "=" + value + "\n");

                }
            }

            if (word == " W ") {
                Iterator entries = dictionary2.entrySet().iterator();
                while (entries.hasNext()) {
                    Map.Entry entry = (Map.Entry) entries.next();
                    String key = (String) entry.getKey();
                    Integer value = (Integer) entry.getValue();
                    editData3.append(key + "=" + value + "\n");

                }
            }


            if (word == "Fatal Exception") {
                Iterator entries = dictionary3.entrySet().iterator();
                while (entries.hasNext()) {
                    Map.Entry entry = (Map.Entry) entries.next();
                    String key = (String) entry.getKey();
                    Integer value = (Integer) entry.getValue();
                    editData6.append(key + "=" + value + "\n");

                }
            }
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return count;

    }
    public static  String wordsix(String strLine)
{

    String word="";
    String[] words=strLine.split(" ");
    for(int i=0;i<=words.length;i++)
   {
       if(words.length>5) {

          word=   words[5];
       }

    }


    return word;
}

    public static int indexOfIgnoreCase(@Nullable String str, @Nullable String searchStr, int startPos) {
        if (str == null || searchStr == null) {
            return INDEX_NOT_FOUND;
        }
        if (startPos < 0) {
            startPos = 0;
        }
        final int endLimit = str.length() - searchStr.length() + 1;
        if (startPos > endLimit) {
            return INDEX_NOT_FOUND;
        }

        for (int i = startPos; i < endLimit; i++) {
            if (str.regionMatches(false, i, searchStr, 0, searchStr.length())) {
                //System.out.println("this is searched string=="+searchStr);
                return i;

            }
        }
        return INDEX_NOT_FOUND;
    }
























    }
