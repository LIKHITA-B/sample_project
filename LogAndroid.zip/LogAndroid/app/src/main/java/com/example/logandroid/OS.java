package com.example.logandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.widget.EditText;

public class OS extends AppCompatActivity {
    EditText editData1,editData2,editData3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_os);

        editData1=(EditText)findViewById(R.id.editData1);
        editData2=(EditText)findViewById(R.id.editData2);
        editData3=(EditText)findViewById(R.id.editData3);
        editData1.setText( Build.VERSION.RELEASE);
        editData2.setText( Build.VERSION.SDK);
        editData3.setText(Build.FINGERPRINT);
        this.setTitle("OS");
    }
}
