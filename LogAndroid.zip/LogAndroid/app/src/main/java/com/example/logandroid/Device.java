package com.example.logandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

public class Device extends AppCompatActivity {
    EditText editData1,editData2,editData3,editData4,editData5,editData6,editData7,editData8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device);
        editData1=(EditText)findViewById(R.id.editData1);
        editData2=(EditText)findViewById(R.id.editData2);
        editData3=(EditText)findViewById(R.id.editData3);
        editData4=(EditText)findViewById(R.id.editData4);
        editData5=(EditText)findViewById(R.id.editData5);
        editData6=(EditText)findViewById(R.id.editData6);
        editData7=(EditText)findViewById(R.id.editData7);
        editData8=(EditText)findViewById(R.id.editData8);


        editData1.setText("Manufacture :" + Build.MANUFACTURER);
        editData2.setText("Brand :" + Build.BRAND);
        editData3.setText("MODEL :" + Build.MODEL);
        editData4.setText("BOARD :" + Build.BOARD);
        editData5.setText("SERIAL: " + Build.SERIAL);
        editData6.setText("ID :" + Build.ID);
        editData7.setText("User :" + Build.USER);
        editData8.setText("HOST " + Build.HOST);
        this.setTitle("Device");



    }
}
