package com.example.logandroid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FirstActivity extends AppCompatActivity {
    Button addbtn,device_btn,OS_btn;
    Button bat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        addbtn=(Button)findViewById(R.id.Add_btn);
        device_btn=(Button)findViewById(R.id.device_btn);
        OS_btn=(Button)findViewById(R.id.OS_btn);
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(FirstActivity.this,MainActivity.class);
                startActivity(in);
            }
        });

        device_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(FirstActivity.this,Device.class);
                startActivity(in);
            }
        });
        bat=(Button)findViewById(R.id.bat);
        bat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(FirstActivity.this,ThirdActivity.class);
                startActivity(in);
            }
        });

        OS_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(FirstActivity.this,OS.class);
                startActivity(in);
            }
        });


    }
}
