package com.example.sample2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;

import android.util.Log;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.lang.String;

public class MainActivity extends AppCompatActivity {
    Button btnView,btnSave;
    EditText editData,fileName;
    String mText;
    String mFile;


    File path1= Environment.getExternalStorageDirectory();
    File dir1=new File(path1+"/My Files/");
    private String filename1 = "";
    private String filepath = path1+"/My Files/";
    File myExternalFile;
    String myData = "";
    private static final int WRITE_EXTERNAL_STORAGE_CODE=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        fileName=(EditText)findViewById(R.id.editFile);
        editData=(EditText)findViewById(R.id.editData);

        btnView=(Button)findViewById(R.id.btnView);
        btnSave=(Button)findViewById(R.id.btnSave);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mText=editData.getText().toString().trim();
                if(mText.isEmpty())
                {
                    Toast.makeText(MainActivity.this,"please enter",Toast.LENGTH_SHORT).show();

                }
                else
                {
                    if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.M)
                    {
                        if(checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED)
                        {
                            String[] permissions={Manifest.permission.WRITE_EXTERNAL_STORAGE};
                            requestPermissions(permissions,WRITE_EXTERNAL_STORAGE_CODE);
                        }
                        else
                        {
                            saveToTxtFile(mText);
                        }
                    }
                    else
                    {
                        saveToTxtFile(mText);
                    }
                }
            }
        });





        mFile=fileName.getText().toString().trim();
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in =new Intent(MainActivity.this,FirstActivity.class);
                startActivity(in);
                }});



    }


















    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode)
        {
            case WRITE_EXTERNAL_STORAGE_CODE:{
                if(grantResults.length>0 &&grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    saveToTxtFile(mText);
                }
                else
                {
                    Toast.makeText(MainActivity.this,"storage permission",Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void saveToTxtFile(String mText){
        String timestamp=new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(System.currentTimeMillis());
        mFile=fileName.getText().toString().trim();
        try{
            File path= Environment.getExternalStorageDirectory();
            File dir=new File(path+"/My Files/");
            dir.mkdirs();
            String filename=mFile;
            File file=new File(dir,filename);
            FileWriter fw=new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw= new BufferedWriter(fw);
            bw.write(mText);
            bw.close();

            Toast.makeText(this,filename+"is saved to\n"+dir,Toast.LENGTH_SHORT).show();
        }catch(Exception e)
        {
            Toast.makeText(this,e.getMessage(),Toast.LENGTH_SHORT).show();
        }

    }










}
