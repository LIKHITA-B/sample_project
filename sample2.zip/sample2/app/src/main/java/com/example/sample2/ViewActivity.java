package com.example.sample2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class ViewActivity extends AppCompatActivity {
    Button btnView,btnback;
    EditText editData,fileName;
    String mText;
    String mFile;
    File path1= Environment.getExternalStorageDirectory();
    File dir1=new File(path1+"/My Files/");
    private String filename1 = "";
    private String filepath = path1+"/My Files/";
    File myExternalFile;
    String myData = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_view);
        fileName=(EditText)findViewById(R.id.editFile);
        editData=(EditText)findViewById(R.id.editData);

        btnView=(Button)findViewById(R.id.btnView);
        btnback=(Button)findViewById(R.id.btnBack);
        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in=new Intent(ViewActivity.this,FirstActivity.class);
                startActivity(in);
            }
        });



        mFile=fileName.getText().toString().trim();
        btnView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {

                    mFile = fileName.getText().toString().trim();
                    if (mFile.toString() != null && mFile.toString().trim() != "") {
                        FileInputStream fis = new FileInputStream("/storage/emulated/0/My Files/"+mFile);
                        DataInputStream in = new DataInputStream(fis);
                        BufferedReader br =
                                new BufferedReader(new InputStreamReader(in));
                        String strLine;
                        while ((strLine = br.readLine()) != null) {
                            myData = myData + strLine;
                        }
                        in.close();


                        editData.setText(myData);
                    } else {
                        Toast.makeText(getApplicationContext(), "file name cannot be blank", Toast.LENGTH_LONG).show();
                    }


                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }});

        if (!isExternalStorageAvailable() || isExternalStorageReadOnly()) {
            btnback.setEnabled(false);
        }
        else {
            myExternalFile = new File(getExternalFilesDir(filepath), mFile);
        }


    }
    private static boolean isExternalStorageReadOnly() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStorageState)) {
            return true;
        }
        return false;
    }

    private static boolean isExternalStorageAvailable() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(extStorageState)) {
            return true;
        }
        return false;
    }


}

